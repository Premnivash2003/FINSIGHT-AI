import { registerChatRoutes } from "./replit_integrations/chat";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { setupAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);

  const requireAuth = (req: any, res: any, next: any) => {
    // skip auth for now
    next();
  };

  // Products
  app.get(api.products.list.path, requireAuth, async (req, res) => {
    const items = await storage.getProducts();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.products.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.products.create.input.parse(req.body);
      const item = await storage.createProduct({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });

  app.post(api.products.bulkCreate.path, requireAuth, async (req, res) => {
    try {
      const input = api.products.bulkCreate.input.parse(req.body);
      const results = [];
      for (const product of input) {
        const item = await storage.createProduct({ ...product, userId: req.user!.id });
        results.push(item);
      }
      res.status(201).json(results);
    } catch (err) {
      console.error("Bulk upload error:", err);
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      res.status(500).json({ message: "Internal server error during bulk upload" });
    }
  });

  app.put(api.products.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.products.update.input.parse(req.body);
      const item = await storage.updateProduct(Number(req.params.id), input);
      res.status(200).json(item);
    } catch (err) {
      res.status(500).json(err);
    }
  });
  app.delete(api.products.delete.path, requireAuth, async (req, res) => {
    await storage.deleteProduct(Number(req.params.id));
    res.status(204).send();
  });

  // Vendors
  app.get(api.vendors.list.path, requireAuth, async (req, res) => {
    const items = await storage.getVendors();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.vendors.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.vendors.create.input.parse(req.body);
      const item = await storage.createVendor({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });
  app.put(api.vendors.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.vendors.update.input.parse(req.body);
      const item = await storage.updateVendor(Number(req.params.id), input);
      res.status(200).json(item);
    } catch (err) {
      res.status(500).json(err);
    }
  });
  app.delete(api.vendors.delete.path, requireAuth, async (req, res) => {
    await storage.deleteVendor(Number(req.params.id));
    res.status(204).send();
  });

  // Workers
  app.get(api.workers.list.path, requireAuth, async (req, res) => {
    const items = await storage.getWorkers();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.workers.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.workers.create.input.parse(req.body);
      const item = await storage.createWorker({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });
  app.put(api.workers.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.workers.update.input.parse(req.body);
      const item = await storage.updateWorker(Number(req.params.id), input);
      res.status(200).json(item);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // Salary Payments
  app.get(api.salaryPayments.list.path, requireAuth, async (req, res) => {
    const items = await storage.getSalaryPayments();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.salaryPayments.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.salaryPayments.create.input.parse(req.body);
      const item = await storage.createSalaryPayment({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });
  app.put(api.salaryPayments.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.salaryPayments.update.input.parse(req.body);
      const item = await storage.updateSalaryPayment(Number(req.params.id), input);
      res.status(200).json(item);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // Sales
  app.get(api.sales.list.path, requireAuth, async (req, res) => {
    const items = await storage.getSales();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.sales.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.sales.create.input.parse(req.body);
      const item = await storage.createSale({ 
        date: new Date(input.date), 
        totalAmount: String(input.totalAmount), 
        userId: req.user!.id 
      });

      const products = await storage.getProducts();
      for (const saleItem of input.items) {
        await storage.createSaleItem({
          saleId: item.id,
          productId: saleItem.productId,
          quantity: saleItem.quantity,
          unitPrice: String(saleItem.unitPrice)
        });
        
        const product = products.find(p => p.id === saleItem.productId);
        if (product) {
          await storage.updateProduct(product.id, {
            currentStock: Math.max(0, product.currentStock - saleItem.quantity)
          });
        }
      }

      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });

  app.delete(api.sales.delete.path, requireAuth, async (req, res) => {
    await storage.deleteSale(Number(req.params.id));
    res.status(204).send();
  });

  // Purchases
  app.get(api.purchases.list.path, requireAuth, async (req, res) => {
    const items = await storage.getPurchases();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.purchases.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.purchases.create.input.parse(req.body);
      const item = await storage.createPurchase({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });

  // Expenses
  app.get(api.expenses.list.path, requireAuth, async (req, res) => {
    const items = await storage.getExpenses();
    res.json(items.filter(i => i.userId === req.user!.id));
  });
  app.post(api.expenses.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.expenses.create.input.parse(req.body);
      const item = await storage.createExpense({ ...input, userId: req.user!.id });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json(err);
    }
  });

  app.delete(api.expenses.delete.path, requireAuth, async (req, res) => {
    await storage.deleteExpense(Number(req.params.id));
    res.status(204).send();
  });

  // Analytics
  app.get(api.analytics.dashboard.path, requireAuth, async (req, res) => {
    const sales = await storage.getSales();
    const expenses = await storage.getExpenses();
    const purchases = await storage.getPurchases();

    const userSales = sales.filter(s => s.userId === req.user!.id);
    const userExpenses = expenses.filter(e => e.userId === req.user!.id);
    const userPurchases = purchases.filter(p => p.userId === req.user!.id);

    const totalSales = userSales.reduce((sum, s) => sum + Number(s.totalAmount), 0);
    const totalExpenses = userExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const totalPurchases = userPurchases.reduce((sum, p) => sum + Number(p.totalAmount), 0);

    const netProfit = totalSales - totalExpenses - totalPurchases;

    // Generate monthly data
    const monthlyData = new Map<string, { name: string, revenue: number, expense: number }>();
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    months.forEach(m => monthlyData.set(m, { name: m, revenue: 0, expense: 0 }));

    userSales.forEach(s => {
      const m = months[new Date(s.date).getMonth()];
      if (monthlyData.has(m)) monthlyData.get(m)!.revenue += Number(s.totalAmount);
    });
    userExpenses.forEach(e => {
      const m = months[new Date(e.date).getMonth()];
      if (monthlyData.has(m)) monthlyData.get(m)!.expense += Number(e.amount);
    });
    userPurchases.forEach(p => {
      const m = months[new Date(p.date).getMonth()];
      if (monthlyData.has(m)) monthlyData.get(m)!.expense += Number(p.totalAmount);
    });
    let revenueData = Array.from(monthlyData.values()).filter(d => d.revenue > 0 || d.expense > 0);
    if (revenueData.length === 0) {
      revenueData = [{ name: months[new Date().getMonth()], revenue: 0, expense: 0 }];
    }

    res.json({
      totalSales,
      totalExpenses: totalExpenses + totalPurchases,
      netProfit,
      cashBalance: netProfit,
      inventoryValue: totalPurchases,
      accountsPayable: totalPurchases * 0.1,
      pendingSalaries: 0,
      revenueData
    });
  });


    // Forecasting
    app.get(api.analytics.forecasting.path, requireAuth, async (req, res) => {
      const sales = await storage.getSales();
      const userSales = sales.filter(s => s.userId === req.user!.id);
      
      // Simple predictive logic: Assume a 10% growth for next month
      const totalSales = userSales.reduce((sum, s) => sum + Number(s.totalAmount), 0);
      const avgMonthlySale = userSales.length > 0 ? totalSales / Math.max(1, userSales.length) : 0;
      const forecastRevenue = avgMonthlySale * 1.1;

      const expenses = await storage.getExpenses();
      const userExpenses = expenses.filter(e => e.userId === req.user!.id);
      const totalExpenses = userExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
      const avgMonthlyExpense = userExpenses.length > 0 ? totalExpenses / Math.max(1, userExpenses.length) : 0;
      const forecastExpense = avgMonthlyExpense * 1.05; // 5% increase

      const forecastClosingBalance = forecastRevenue - forecastExpense;

      const products = await storage.getProducts();
      const userProducts = products.filter(p => p.userId === req.user!.id);
      const stockNeeded = userProducts.filter(p => p.currentStock <= p.reorderLevel).map(p => ({
        name: p.name,
        amountNeeded: Math.max(p.reorderLevel * 2 - p.currentStock, 0)
      }));

      res.json({
        forecastRevenue,
        forecastExpense,
        forecastClosingBalance,
        stockNeeded
      });
    });

    // Summary
    app.get(api.analytics.summary.path, requireAuth, async (req, res) => {
      const sales = await storage.getSales();
      const expenses = await storage.getExpenses();
      const purchases = await storage.getPurchases();
      const salaryPayments = await storage.getSalaryPayments();

      const userSales = sales.filter(s => s.userId === req.user!.id);
      const userExpenses = expenses.filter(e => e.userId === req.user!.id);
      const userPurchases = purchases.filter(p => p.userId === req.user!.id);
      const userSalaries = salaryPayments.filter(s => s.userId === req.user!.id);

      const revenue = userSales.reduce((sum, s) => sum + Number(s.totalAmount), 0);
      const opExpense = userExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
      const costOfGoods = userPurchases.reduce((sum, p) => sum + Number(p.totalAmount), 0);
      const salaries = userSalaries.reduce((sum, s) => sum + Number(s.amount), 0);

      const expense = opExpense + costOfGoods + salaries;
      const cashInflow = revenue;
      const cashOutflow = expense;
      const netCashflow = cashInflow - cashOutflow;

      const avgMonthlySale = userSales.length > 0 ? revenue / Math.max(1, userSales.length) : 0;
      const forecastRevenue = avgMonthlySale * 1.1;
      const avgMonthlyExpense = userExpenses.length > 0 ? opExpense / Math.max(1, userExpenses.length) : 0;
      const forecastExpense = avgMonthlyExpense * 1.05;
      const forecastClosingBalance = forecastRevenue - forecastExpense;

      res.json({
        revenue,
        expense,
        cashInflow,
        cashOutflow,
        netCashflow,
        forecastRevenue,
        forecastClosingBalance,
        chartData: [
          { name: 'Current', revenue, expense, netCashflow },
          { name: 'Forecast', revenue: forecastRevenue, expense: forecastExpense, netCashflow: forecastClosingBalance }
        ]
      });
    });

    // Stock Risk
    app.get(api.analytics.stockRisk.path, requireAuth, async (req, res) => {
      const products = await storage.getProducts();
      const userProducts = products.filter(p => p.userId === req.user!.id);
      
      // Find products below reorder level
      const lowStockProducts = userProducts.filter(p => p.currentStock <= p.reorderLevel).map(p => {
        // Recommend buying 2x reorder level minus current stock
        const recommendation = Math.max(p.reorderLevel * 2 - p.currentStock, 0);
        return {
          id: p.id,
          name: p.name,
          currentStock: p.currentStock,
          reorderLevel: p.reorderLevel,
          recommendation
        };
      });

      res.json({ lowStockProducts });
    });
  
  // Chatbot
    app.post(api.analytics.chat.path, requireAuth, async (req, res) => {
      try {
        const { query } = req.body;
        const products = await storage.getProducts();
        const sales = await storage.getSales();
        const expenses = await storage.getExpenses();
        const vendors = await storage.getVendors();
        const workers = await storage.getWorkers();
        const purchases = await storage.getPurchases();

        const userProducts = products.filter(p => p.userId === req.user!.id);
        const userSales = sales.filter(s => s.userId === req.user!.id);
        const userExpenses = expenses.filter(e => e.userId === req.user!.id);
        const userVendors = vendors.filter(v => v.userId === req.user!.id);
        const userWorkers = workers.filter(w => w.userId === req.user!.id);
        const userPurchases = purchases.filter(p => p.userId === req.user!.id);
        
        const totalRevenue = userSales.reduce((sum, s) => sum + Number(s.totalAmount), 0);
        const totalExpenses = userExpenses.reduce((sum, e) => sum + Number(e.amount), 0);
        const productCount = userProducts.length;
        const lowStockProducts = userProducts.filter(p => p.currentStock <= p.reorderLevel);

        const systemPrompt = `You are an AI financial and inventory advisor for FINSIGHT. 
  Answer the user's questions based on the following business data:
  - Total Revenue: ₹${totalRevenue.toFixed(2)}
  - Total Expenses: ₹${totalExpenses.toFixed(2)}
  - Net Profit: ₹${(totalRevenue - totalExpenses).toFixed(2)}
  - Total Products: ${productCount}
  - Low Stock Products: ${lowStockProducts.map(p => p.name).join(', ')} (${lowStockProducts.length} items)
  - Total Workers: ${userWorkers.length} (Details: ${userWorkers.map(w => w.name + ' - ' + w.role).join(', ')})
  - Total Vendors: ${userVendors.length} (Details: ${userVendors.map(v => v.name + ' - ' + v.contact).join(', ')})
  - Stock Left: ${userProducts.reduce((sum, p) => sum + p.currentStock, 0)} total items across all products
  - Forecasting: Based on current trends, revenue forecast for next month is ₹${(totalRevenue * 1.1).toFixed(2)} and expenses forecast is ₹${(totalExpenses * 1.05).toFixed(2)}.

  You can also provide predictive analysis and forecasting based on the current trends. Answer comprehensively but concisely. Do not use dollar signs, use rupees (₹).`;

        // Use openai from the integration
        const { openai } = await import("./replit_integrations/audio/client.js"); // openai is exported from there or chat/client
        // wait, the openai client is in replit_integrations/chat/routes.ts but not exported?
        // actually, the blueprint provides openai in image/client.ts or chat/routes.ts
        
        // Let's just create a new openai client here
        const { default: OpenAI } = await import("openai");
        const openaiClient = new OpenAI({
          apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
          baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
        });

        const response = await openaiClient.chat.completions.create({
          model: "gpt-5.2",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: query }
          ],
        });

        res.json({ response: response.choices[0]?.message?.content || "I couldn't process that request." });
      } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Failed to get AI response" });
      }
    });

    return httpServer;
  }
  