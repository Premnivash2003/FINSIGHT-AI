import { users, type User, type InsertUser, products, type Product, type InsertProduct, vendors, type Vendor, type InsertVendor, workers, type Worker, type InsertWorker, salaryPayments, type SalaryPayment, type InsertSalaryPayment, sales, type Sale, type InsertSale, saleItems, type SaleItem, type InsertSaleItem, purchases, type Purchase, type InsertPurchase, expenses, type Expense, type InsertExpense } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getProducts(): Promise<Product[]>;
  createProduct(product: Omit<InsertProduct, "id">): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  getVendors(): Promise<Vendor[]>;
  createVendor(vendor: Omit<InsertVendor, "id">): Promise<Vendor>;
  updateVendor(id: number, updates: Partial<InsertVendor>): Promise<Vendor>;
  deleteVendor(id: number): Promise<void>;

  getWorkers(): Promise<Worker[]>;
  deleteWorker(id: number): Promise<void>;
  createWorker(worker: Omit<InsertWorker, "id">): Promise<Worker>;
  updateWorker(id: number, updates: Partial<InsertWorker>): Promise<Worker>;

  getSalaryPayments(): Promise<SalaryPayment[]>;
  createSalaryPayment(payment: Omit<InsertSalaryPayment, "id">): Promise<SalaryPayment>;
  updateSalaryPayment(id: number, updates: Partial<InsertSalaryPayment>): Promise<SalaryPayment>;

  getSales(): Promise<Sale[]>;
  createSale(sale: Omit<InsertSale, "id">): Promise<Sale>;
  getSaleItems(): Promise<SaleItem[]>;
  createSaleItem(item: Omit<InsertSaleItem, "id">): Promise<SaleItem>;
  deleteSale(id: number): Promise<void>;

  getPurchases(): Promise<Purchase[]>;
  createPurchase(purchase: Omit<InsertPurchase, "id">): Promise<Purchase>;

  getExpenses(): Promise<Expense[]>;
  createExpense(expense: Omit<InsertExpense, "id">): Promise<Expense>;
  deleteExpense(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getProducts() { return await db.select().from(products); }
  async createProduct(p: Omit<InsertProduct, "id">) { const [row] = await db.insert(products).values(p).returning(); return row; }
  async updateProduct(id: number, updates: Partial<InsertProduct>) { const [row] = await db.update(products).set(updates).where(eq(products.id, id)).returning(); return row; }
  async deleteProduct(id: number) { await db.delete(products).where(eq(products.id, id)); }

  async getVendors() { return await db.select().from(vendors); }
  async createVendor(v: Omit<InsertVendor, "id">) { const [row] = await db.insert(vendors).values(v).returning(); return row; }
  async updateVendor(id: number, updates: Partial<InsertVendor>) { const [row] = await db.update(vendors).set(updates).where(eq(vendors.id, id)).returning(); return row; }
  async deleteVendor(id: number) { await db.delete(vendors).where(eq(vendors.id, id)); }

  async getWorkers() { return await db.select().from(workers); }
  async createWorker(w: Omit<InsertWorker, "id">) { const [row] = await db.insert(workers).values(w).returning(); return row; }
  async updateWorker(id: number, updates: Partial<InsertWorker>) { const [row] = await db.update(workers).set(updates).where(eq(workers.id, id)).returning(); return row; }

  async getSalaryPayments() { return await db.select().from(salaryPayments); }
  async createSalaryPayment(sp: Omit<InsertSalaryPayment, "id">) { const [row] = await db.insert(salaryPayments).values(sp).returning(); return row; }
  async updateSalaryPayment(id: number, updates: Partial<InsertSalaryPayment>) { const [row] = await db.update(salaryPayments).set(updates).where(eq(salaryPayments.id, id)).returning(); return row; }

  async getSales() { return await db.select().from(sales); }
  async createSale(s: Omit<InsertSale, "id">) { const [row] = await db.insert(sales).values(s).returning(); return row; }

  async getSaleItems() { return await db.select().from(saleItems); }
  async createSaleItem(si: Omit<InsertSaleItem, "id">) { const [row] = await db.insert(saleItems).values(si).returning(); return row; }
  async deleteSale(id: number) { 
    await db.delete(saleItems).where(eq(saleItems.saleId, id));
    await db.delete(sales).where(eq(sales.id, id)); 
  }

  async getPurchases() { return await db.select().from(purchases); }
  async createPurchase(p: Omit<InsertPurchase, "id">) { const [row] = await db.insert(purchases).values(p).returning(); return row; }

  async getExpenses() { return await db.select().from(expenses); }
  async createExpense(e: Omit<InsertExpense, "id">) { const [row] = await db.insert(expenses).values(e).returning(); return row; }
  async deleteExpense(id: number) { await db.delete(expenses).where(eq(expenses.id, id)); }
}

export const storage = new DatabaseStorage();
