import { useState } from "react";
import { useSales, useCreateSale, useProducts } from "@/hooks/use-finance";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, ShoppingCart, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

const saleSchema = z.object({
  productId: z.coerce.number().min(1, "Select a product"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
});

export default function Sales() {
  const { data: sales = [], isLoading } = useSales();
  const { data: products = [] } = useProducts();
  const createSale = useCreateSale();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/sales/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({ title: "Sale deleted successfully" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });

  const form = useForm<z.infer<typeof saleSchema>>({
    resolver: zodResolver(saleSchema),
    defaultValues: { quantity: 1, productId: 0 }
  });

  const onSubmit = async (data: z.infer<typeof saleSchema>) => {
    try {
      const product = products.find(p => p.id === data.productId);
      if (!product) throw new Error("Product not found");
      if (product.currentStock < data.quantity) {
        throw new Error(`Insufficient stock. Only ${product.currentStock} available.`);
      }

      const totalAmount = data.quantity * Number(product.sellingPrice);

      await createSale.mutateAsync({
        date: new Date().toISOString().split('T')[0],
        totalAmount,
        items: [{
          productId: data.productId,
          quantity: data.quantity,
          unitPrice: product.sellingPrice
        }]
      });
      toast({ title: "Sale recorded successfully" });
      setOpen(false);
      form.reset();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Sales & Invoices</h1>
          <p className="text-muted-foreground">Track daily sales and revenue.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4 mr-2" /> Record Sale
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display text-xl">Record New Sale</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Select Product</Label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  {...form.register("productId")}
                >
                  <option value={0}>-- Select Product --</option>
                  {products.map(p => (
                    <option key={p.id} value={p.id}>{p.name} (₹{Number(p.sellingPrice).toFixed(2)}) - {p.currentStock} in stock</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input type="number" {...form.register("quantity")} />
              </div>
              <Button type="submit" className="w-full mt-4" disabled={createSale.isPending}>
                {createSale.isPending ? "Processing..." : "Complete Sale"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-0 shadow-md overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Transaction ID</TableHead>
                <TableHead className="text-right">Total Amount</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : sales.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-16 text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <ShoppingCart className="w-12 h-12 text-muted mb-4" />
                      <p>No sales recorded yet.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : sales.map(s => (
                <TableRow key={s.id} className="hover:bg-muted/10 transition-colors">
                  <TableCell className="font-medium">{format(new Date(s.date), 'MMM dd, yyyy')}</TableCell>
                  <TableCell className="text-muted-foreground">INV-{s.id.toString().padStart(5, '0')}</TableCell>
                  <TableCell className="text-right font-bold text-primary">₹{Number(s.totalAmount).toFixed(2)}</TableCell>
                  <TableCell className="text-center">
                    <span className="inline-flex items-center text-xs font-medium text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
                      Paid
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => deleteMutation.mutate(s.id)}
                      data-testid={`button-delete-sale-${s.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
