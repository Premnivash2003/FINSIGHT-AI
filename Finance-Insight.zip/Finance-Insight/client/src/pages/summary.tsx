import { useSummary } from "@/hooks/use-finance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from "recharts";

export default function Summary() {
  const { data: summary, isLoading } = useSummary();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-3xl font-display font-bold">Financial Summary</h1>
        <p className="text-muted-foreground">Comprehensive overview of your business performance</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Revenue</p>
              <div className="p-2 bg-primary/10 rounded-full">
                <DollarSign className="h-4 w-4 text-primary" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.revenue?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Total income</p>
          </CardContent>
        </Card>
        
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Expenses</p>
              <div className="p-2 bg-destructive/10 rounded-full">
                <TrendingDown className="h-4 w-4 text-destructive" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.expense?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Total outflow</p>
          </CardContent>
        </Card>

        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Cash Inflow</p>
              <div className="p-2 bg-green-500/10 rounded-full">
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.cashInflow?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Money received</p>
          </CardContent>
        </Card>

        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Cash Outflow</p>
              <div className="p-2 bg-orange-500/10 rounded-full">
                <TrendingDown className="h-4 w-4 text-orange-500" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.cashOutflow?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Money paid</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Net Cashflow</p>
              <div className="p-2 bg-primary/10 rounded-full">
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.netCashflow?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Inflow - Outflow</p>
          </CardContent>
        </Card>
        
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Forecast Closing Balance</p>
              <div className="p-2 bg-green-500/10 rounded-full">
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{summary?.forecastClosingBalance?.toFixed(2) || 0}</div>
            <p className="text-xs text-green-500 font-medium mt-1">Next month prediction</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-md">
        <CardHeader>
          <CardTitle className="font-display font-semibold">Current vs Forecast Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={summary?.chartData || []} margin={{ top: 10, right: 30, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Legend />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} barSize={50} />
                <Bar dataKey="expense" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} barSize={50} />
                <Bar dataKey="netCashflow" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} barSize={50} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
