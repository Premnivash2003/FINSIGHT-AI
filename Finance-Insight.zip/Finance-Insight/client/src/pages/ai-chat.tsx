import { useState, useRef, useEffect } from "react";
import { useChat } from "@/hooks/use-finance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, User, Send, Sparkles } from "lucide-react";

export default function AiChat() {
  const [messages, setMessages] = useState<{role: 'user'|'ai', content: string}[]>([
    { role: 'ai', content: "Hello! I'm your FINSIGHT AI advisor. You can ask me questions about your financial health, profit margins, inventory costs, vendor details, worker information, stock levels, forecasting, or any business summary." }
  ]);
  const [input, setInput] = useState("");
  const chatMutation = useChat();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);

    try {
      const response = await chatMutation.mutateAsync(userMsg);
      setMessages(prev => [...prev, { role: 'ai', content: response }]);
    } catch {
      setMessages(prev => [...prev, { role: 'ai', content: "Sorry, I'm having trouble connecting right now. Please try again later." }]);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <Sparkles className="w-8 h-8 text-primary" />
          AI Financial Advisor
        </h1>
        <p className="text-muted-foreground">Get insights, forecasts, and strategic advice instantly.</p>
      </div>

      <Card className="flex-1 border-0 shadow-lg flex flex-col overflow-hidden glass-card">
        <CardContent className="flex-1 flex flex-col p-0 overflow-hidden relative">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-4 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {m.role === 'ai' && (
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                    <Bot className="w-5 h-5 text-primary" />
                  </div>
                )}
                <div className={`max-w-[80%] rounded-2xl px-5 py-3.5 shadow-sm ${
                  m.role === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-sm' 
                    : 'bg-muted/50 text-foreground rounded-tl-sm border border-border/50'
                }`}>
                  <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>
                </div>
                {m.role === 'user' && (
                  <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-accent-foreground" />
                  </div>
                )}
              </div>
            ))}
            {chatMutation.isPending && (
              <div className="flex gap-4 justify-start">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5 text-primary animate-pulse" />
                </div>
                <div className="bg-muted/50 rounded-2xl rounded-tl-sm px-5 py-4 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce" style={{animationDelay: '0.4s'}}></div>
                </div>
              </div>
            )}
          </div>
          
          <div className="p-4 bg-background/80 backdrop-blur-md border-t border-border">
            <form 
              className="flex gap-3 max-w-4xl mx-auto relative"
              onSubmit={(e) => { e.preventDefault(); handleSend(); }}
            >
              <Input 
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Ask about profit margins, cost cutting, or forecasts..." 
                className="flex-1 h-14 bg-card shadow-sm rounded-xl pl-6 pr-14 text-base border-border/50 focus:border-primary focus:ring-primary/20"
              />
              <Button 
                type="submit" 
                size="icon" 
                className="absolute right-2 top-2 h-10 w-10 rounded-lg bg-primary hover:bg-primary/90 shadow-md shadow-primary/20 transition-all hover:scale-105"
                disabled={chatMutation.isPending || !input.trim()}
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
