import { useState } from "react";
import { useWorkers, useCreateWorker, useDeleteWorker } from "@/hooks/use-finance";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Users, UserCheck, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const workerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  role: z.string().min(1, "Role is required"),
  monthlySalary: z.coerce.number().min(0, "Salary must be >= 0"),
});

export default function Workers() {
  const { data: workers = [], isLoading } = useWorkers();
  const createWorker = useCreateWorker();
  const deleteWorker = useDeleteWorker();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof workerSchema>>({
    resolver: zodResolver(workerSchema),
    defaultValues: { name: "", role: "", monthlySalary: 0 }
  });

  const onSubmit = async (data: z.infer<typeof workerSchema>) => {
    try {
      await createWorker.mutateAsync({
        name: data.name,
        role: data.role,
        monthlySalary: data.monthlySalary.toString(),
        joiningDate: new Date().toISOString().split('T')[0],
      });
      toast({ title: "Worker added successfully" });
      setOpen(false);
      form.reset();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`Are you sure you want to remove "${name}" from your team? This action cannot be undone.`)) return;
    try {
      await deleteWorker.mutateAsync(id);
      toast({ title: "Worker removed successfully" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Workers & Payroll</h1>
          <p className="text-muted-foreground">Manage staff and view base salaries.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4 mr-2" /> Add Worker
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display text-xl">Add New Worker</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input {...form.register("name")} />
              </div>
              <div className="space-y-2">
                <Label>Role/Position</Label>
                <Input {...form.register("role")} placeholder="e.g. Cashier, Store Manager" />
              </div>
              <div className="space-y-2">
                <Label>Monthly Salary (₹)</Label>
                <Input type="number" step="0.01" {...form.register("monthlySalary")} />
              </div>
              <Button type="submit" className="w-full mt-4" disabled={createWorker.isPending}>
                {createWorker.isPending ? "Saving..." : "Save Worker"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-0 shadow-md overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead>Worker Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Joining Date</TableHead>
                <TableHead className="text-right">Monthly Salary</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : workers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-16 text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Users className="w-12 h-12 text-muted mb-4" />
                      <p>No workers added yet.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : workers.map(w => (
                <TableRow key={w.id} className="hover:bg-muted/10 transition-colors" data-testid={`row-worker-${w.id}`}>
                  <TableCell className="font-medium flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                      {w.name.charAt(0)}
                    </div>
                    <span data-testid={`text-worker-name-${w.id}`}>{w.name}</span>
                  </TableCell>
                  <TableCell data-testid={`text-worker-role-${w.id}`}>{w.role}</TableCell>
                  <TableCell className="text-muted-foreground">{format(new Date(w.joiningDate), 'MMM dd, yyyy')}</TableCell>
                  <TableCell className="text-right font-medium" data-testid={`text-worker-salary-${w.id}`}>₹{Number(w.monthlySalary).toFixed(2)}</TableCell>
                  <TableCell className="text-center">
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
                      <UserCheck className="w-3 h-3" /> Active
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive hover:bg-destructive/10"
                      onClick={() => handleDelete(w.id, w.name)}
                      disabled={deleteWorker.isPending}
                      data-testid={`button-delete-worker-${w.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
