import { useState } from "react";
import { useProducts, useCreateProduct, useUpdateProduct, useDeleteProduct } from "@/hooks/use-finance";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, AlertCircle, CheckCircle2, Upload, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from "xlsx";

const productSchema = z.object({
  name: z.string().min(1, "Name required"),
  category: z.string().min(1, "Category required"),
  costPrice: z.coerce.number().min(0),
  sellingPrice: z.coerce.number().min(0),
  currentStock: z.coerce.number().min(0),
  reorderLevel: z.coerce.number().min(0),
});

export default function Inventory() {
  const { data: products = [], isLoading } = useProducts();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  const form = useForm<z.infer<typeof productSchema>>({
    resolver: zodResolver(productSchema),
    defaultValues: { name: "", category: "", costPrice: 0, sellingPrice: 0, currentStock: 0, reorderLevel: 10 }
  });

  const editForm = useForm<z.infer<typeof productSchema>>({
    resolver: zodResolver(productSchema),
    defaultValues: { name: "", category: "", costPrice: 0, sellingPrice: 0, currentStock: 0, reorderLevel: 10 }
  });

  const onFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        const productsToCreate = json.map((row: any) => ({
          name: String(row.Name || row["Product Name"] || row["name"] || ""),
          category: String(row.Category || row["category"] || "General"),
          costPrice: String(row["Cost Price"] || row["costPrice"] || row["Cost"] || 0),
          sellingPrice: String(row["Selling Price"] || row["sellingPrice"] || row["Price"] || 0),
          currentStock: Number(row["Stock"] || row["Current Stock"] || row["currentStock"] || 0),
          reorderLevel: Number(row["Reorder Level"] || row["reorderLevel"] || 10),
          vendorId: null
        })).filter(p => p.name);

        const response = await fetch("/api/products/bulk", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(productsToCreate),
        });

        if (!response.ok) throw new Error("Bulk upload failed");
        
        toast({ title: "Inventory imported successfully", description: `${productsToCreate.length} products added.` });
      } catch (err: any) {
        toast({ title: "Upload failed", description: err.message, variant: "destructive" });
      } finally {
        setIsUploading(false);
        if (event.target) event.target.value = "";
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const onSubmit = async (data: z.infer<typeof productSchema>) => {
    try {
      await createProduct.mutateAsync({
        ...data,
        costPrice: data.costPrice.toString(),
        sellingPrice: data.sellingPrice.toString(),
        vendorId: null
      });
      toast({ title: "Product added successfully" });
      setOpen(false);
      form.reset();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    editForm.reset({
      name: product.name,
      category: product.category,
      costPrice: Number(product.costPrice),
      sellingPrice: Number(product.sellingPrice),
      currentStock: product.currentStock,
      reorderLevel: product.reorderLevel,
    });
    setEditOpen(true);
  };

  const onEditSubmit = async (data: z.infer<typeof productSchema>) => {
    if (!editingProduct) return;
    try {
      await updateProduct.mutateAsync({
        id: editingProduct.id,
        ...data,
        costPrice: data.costPrice.toString(),
        sellingPrice: data.sellingPrice.toString(),
        vendorId: editingProduct.vendorId
      });
      toast({ title: "Product updated successfully" });
      setEditOpen(false);
      setEditingProduct(null);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) return;
    try {
      await deleteProduct.mutateAsync(id);
      toast({ title: "Product deleted successfully" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.category.toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Inventory</h1>
          <p className="text-muted-foreground">Manage products, stock levels, and pricing.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Button variant="outline" className="shadow-sm" disabled={isUploading}>
              <Upload className="w-4 h-4 mr-2" /> {isUploading ? "Uploading..." : "Import Excel"}
            </Button>
            <input 
              type="file" 
              accept=".xlsx,.xls" 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              onChange={onFileUpload}
              disabled={isUploading}
            />
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all">
                <Plus className="w-4 h-4 mr-2" /> Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle className="font-display text-xl">Add New Product</DialogTitle>
              </DialogHeader>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product Name</Label>
                    <Input {...form.register("name")} placeholder="Apples" />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input {...form.register("category")} placeholder="Produce" />
                  </div>
                  <div className="space-y-2">
                    <Label>Cost Price (₹)</Label>
                    <Input type="number" step="0.01" {...form.register("costPrice")} />
                  </div>
                  <div className="space-y-2">
                    <Label>Selling Price (₹)</Label>
                    <Input type="number" step="0.01" {...form.register("sellingPrice")} />
                  </div>
                  <div className="space-y-2">
                    <Label>Initial Stock</Label>
                    <Input type="number" {...form.register("currentStock")} />
                  </div>
                  <div className="space-y-2">
                    <Label>Reorder Level</Label>
                    <Input type="number" {...form.register("reorderLevel")} />
                  </div>
                </div>
                <Button type="submit" className="w-full mt-4" disabled={createProduct.isPending}>
                  {createProduct.isPending ? "Saving..." : "Save Product"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Edit Product</DialogTitle>
          </DialogHeader>
          <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Product Name</Label>
                <Input {...editForm.register("name")} placeholder="Apples" />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Input {...editForm.register("category")} placeholder="Produce" />
              </div>
              <div className="space-y-2">
                <Label>Cost Price (₹)</Label>
                <Input type="number" step="0.01" {...editForm.register("costPrice")} />
              </div>
              <div className="space-y-2">
                <Label>Selling Price (₹)</Label>
                <Input type="number" step="0.01" {...editForm.register("sellingPrice")} />
              </div>
              <div className="space-y-2">
                <Label>Current Stock</Label>
                <Input type="number" {...editForm.register("currentStock")} />
              </div>
              <div className="space-y-2">
                <Label>Reorder Level</Label>
                <Input type="number" {...editForm.register("reorderLevel")} />
              </div>
            </div>
            <Button type="submit" className="w-full mt-4" disabled={updateProduct.isPending} data-testid="button-save-edit">
              {updateProduct.isPending ? "Saving..." : "Update Product"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Card className="border-0 shadow-md overflow-hidden">
        <div className="p-4 border-b border-border/50 bg-muted/20">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search products..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-background" 
            />
          </div>
        </div>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead>Product Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Cost Price</TableHead>
                <TableHead className="text-right">Selling Price</TableHead>
                <TableHead className="text-right">Stock Level</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No products found</TableCell></TableRow>
              ) : filtered.map(p => (
                <TableRow key={p.id} className="hover:bg-muted/10 transition-colors" data-testid={`row-product-${p.id}`}>
                  <TableCell className="font-medium" data-testid={`text-product-name-${p.id}`}>{p.name}</TableCell>
                  <TableCell>
                    <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-secondary text-secondary-foreground">
                      {p.category}
                    </span>
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground" data-testid={`text-cost-price-${p.id}`}>₹{Number(p.costPrice).toFixed(2)}</TableCell>
                  <TableCell className="text-right font-medium" data-testid={`text-selling-price-${p.id}`}>₹{Number(p.sellingPrice).toFixed(2)}</TableCell>
                  <TableCell className="text-right" data-testid={`text-stock-${p.id}`}>{p.currentStock}</TableCell>
                  <TableCell className="text-center">
                    {p.currentStock <= p.reorderLevel ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-destructive bg-destructive/10 px-2 py-1 rounded-full">
                        <AlertCircle className="w-3 h-3" /> Low Stock
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
                        <CheckCircle2 className="w-3 h-3" /> Healthy
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-primary hover:bg-primary/10"
                        onClick={() => handleEdit(p)}
                        data-testid={`button-edit-${p.id}`}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive hover:bg-destructive/10"
                        onClick={() => handleDelete(p.id, p.name)}
                        disabled={deleteProduct.isPending}
                        data-testid={`button-delete-${p.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
