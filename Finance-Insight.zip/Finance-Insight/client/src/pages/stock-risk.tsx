import { useStockRisk } from "@/hooks/use-finance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, Package, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function StockRisk() {
  const { data: stockRisk, isLoading } = useStockRisk();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const lowStockProducts = stockRisk?.lowStockProducts || [];

  return (
    <>
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <AlertTriangle className="w-8 h-8 text-orange-500" />
          Stock Risk Analysis
        </h1>
        <p className="text-muted-foreground">Monitor low stock products and get AI-powered recommendations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Products at Risk</p>
              <div className="p-2 bg-destructive/10 rounded-full">
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">{lowStockProducts.length}</div>
            <p className="text-xs text-destructive font-medium mt-1">Require immediate action</p>
          </CardContent>
        </Card>
        
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Units Needed</p>
              <div className="p-2 bg-orange-500/10 rounded-full">
                <Package className="h-4 w-4 text-orange-500" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">
              {lowStockProducts.reduce((sum: number, p: any) => sum + p.recommendation, 0)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Recommended restock</p>
          </CardContent>
        </Card>

        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Risk Level</p>
              <div className="p-2 bg-primary/10 rounded-full">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">
              {lowStockProducts.length > 5 ? 'High' : lowStockProducts.length > 2 ? 'Medium' : 'Low'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Overall inventory health</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-md overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-orange-500/10 to-destructive/10">
          <CardTitle className="font-display font-semibold flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            Low Stock Products & Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead>Product Name</TableHead>
                <TableHead className="text-center">Current Stock</TableHead>
                <TableHead className="text-center">Reorder Level</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Recommended Purchase</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lowStockProducts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-16 text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Package className="w-12 h-12 text-green-500 mb-4" />
                      <p className="text-lg font-medium text-green-600">All stock levels healthy!</p>
                      <p className="text-sm text-muted-foreground mt-1">No products require immediate restocking</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : lowStockProducts.map((product: any) => (
                <TableRow key={product.id} className="hover:bg-muted/10 transition-colors" data-testid={`row-stock-risk-${product.id}`}>
                  <TableCell className="font-medium" data-testid={`text-product-name-${product.id}`}>{product.name}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="destructive" className="text-xs" data-testid={`badge-current-stock-${product.id}`}>
                      {product.currentStock} units
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center text-muted-foreground" data-testid={`text-reorder-level-${product.id}`}>
                    {product.reorderLevel} units
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-orange-600 bg-orange-500/10 px-2 py-1 rounded-full">
                      <AlertTriangle className="w-3 h-3" /> Critical
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-2xl font-bold text-primary" data-testid={`text-recommendation-${product.id}`}>
                        {product.recommendation}
                      </span>
                      <span className="text-xs text-muted-foreground">units to order</span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {lowStockProducts.length > 0 && (
        <Card className="border-0 shadow-md mt-6 bg-gradient-to-r from-primary/5 to-primary/10">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-lg mb-2">AI Recommendation</h3>
                <p className="text-muted-foreground">
                  Based on your current sales trends and stock levels, we recommend prioritizing the restocking 
                  of the products listed above. Consider ordering in bulk to take advantage of volume discounts 
                  from your vendors. The recommended quantities are calculated to bring stock levels to 2x your 
                  reorder threshold, ensuring buffer inventory for unexpected demand spikes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}
