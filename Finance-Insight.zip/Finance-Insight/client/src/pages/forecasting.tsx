import { useForecasting } from "@/hooks/use-finance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, DollarSign, Package, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

export default function Forecasting() {
  const { data: forecast, isLoading } = useForecasting();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const forecastData = [
    { name: 'Current Month', revenue: forecast?.forecastRevenue * 0.9 || 0, expense: forecast?.forecastExpense * 0.95 || 0 },
    { name: 'Next Month', revenue: forecast?.forecastRevenue || 0, expense: forecast?.forecastExpense || 0 }
  ];

  return (
    <>
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-3xl font-display font-bold">Predictive Forecasting</h1>
        <p className="text-muted-foreground">AI-powered predictions for next month's financial performance</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Forecast Revenue</p>
              <div className="p-2 bg-primary/10 rounded-full">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{forecast?.forecastRevenue?.toFixed(2) || 0}</div>
            <p className="text-xs text-green-500 font-medium mt-1">Next month prediction</p>
          </CardContent>
        </Card>
        
        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Forecast Expense</p>
              <div className="p-2 bg-destructive/10 rounded-full">
                <DollarSign className="h-4 w-4 text-destructive" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{forecast?.forecastExpense?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Projected expenses</p>
          </CardContent>
        </Card>

        <Card className="hover-lift border-0 shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0 pb-2">
              <p className="text-sm font-medium text-muted-foreground">Forecast Closing Balance</p>
              <div className="p-2 bg-green-500/10 rounded-full">
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
            </div>
            <div className="text-3xl font-display font-bold mt-2">₹{forecast?.forecastClosingBalance?.toFixed(2) || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Net position</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="font-display font-semibold">Revenue & Expense Forecast</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={forecastData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} barSize={40} />
                  <Bar dataKey="expense" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="font-display font-semibold flex items-center gap-2">
              <Package className="w-5 h-5 text-primary" />
              Stock Needed Next Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {forecast?.stockNeeded && forecast.stockNeeded.length > 0 ? (
                forecast.stockNeeded.map((item: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center">
                        <AlertCircle className="w-4 h-4 text-orange-500" />
                      </div>
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <span className="text-sm font-bold text-primary">{item.amountNeeded} units</span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Package className="w-12 h-12 text-muted mx-auto mb-2" />
                  <p>All stock levels healthy</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
