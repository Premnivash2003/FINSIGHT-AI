import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { 
  Product, Vendor, Worker, SalaryPayment, Sale, Purchase, Expense,
  InsertProduct, InsertVendor, InsertWorker, InsertSalaryPayment, InsertPurchase, InsertExpense 
} from "@shared/schema";
import { z } from "zod";

// --- PRODUCTS ---
export function useProducts() {
  return useQuery<Product[]>({
    queryKey: [api.products.list.path],
    queryFn: async () => {
      const res = await fetch(api.products.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch products");
      return await res.json();
    },
  });
}

export function useCreateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<InsertProduct, 'userId'>) => {
      const res = await fetch(api.products.create.path, {
        method: api.products.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create product");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.products.list.path] }),
  });
}


  export function useUpdateProduct() {
    const queryClient = useQueryClient();
    return useMutation({
      mutationFn: async ({ id, ...data }: Partial<InsertProduct> & { id: number }) => {
        const res = await fetch(`/api/products/${id}`, {
          method: 'PUT',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to update product");
        return await res.json();
      },
      onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.products.list.path] }),
    });
  }

  export function useDeleteProduct() {
    const queryClient = useQueryClient();
    return useMutation({
      mutationFn: async (id: number) => {
        const res = await fetch(`/api/products/${id}`, {
          method: 'DELETE',
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to delete product");
        return true;
      },
      onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.products.list.path] }),
    });
  }
  
// --- VENDORS ---
export function useVendors() {
  return useQuery<Vendor[]>({
    queryKey: [api.vendors.list.path],
    queryFn: async () => {
      const res = await fetch(api.vendors.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch vendors");
      return await res.json();
    },
  });
}

export function useCreateVendor() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<InsertVendor, 'userId'>) => {
      const res = await fetch(api.vendors.create.path, {
        method: api.vendors.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create vendor");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.vendors.list.path] }),
  });
}


  export function useDeleteVendor() {
    const queryClient = useQueryClient();
    return useMutation({
      mutationFn: async (id: number) => {
        const res = await fetch(`/api/vendors/${id}`, {
          method: 'DELETE',
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to delete vendor");
        return true;
      },
      onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.vendors.list.path] }),
    });
  }

  export function useDeleteWorker() {
    const queryClient = useQueryClient();
    return useMutation({
      mutationFn: async (id: number) => {
        const res = await fetch(`/api/workers/${id}`, {
          method: 'DELETE',
          credentials: "include",
        });
        if (!res.ok) throw new Error("Failed to delete worker");
        return true;
      },
      onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.workers.list.path] }),
    });
  }
  
// --- EXPENSES ---
export function useExpenses() {
  return useQuery<Expense[]>({
    queryKey: [api.expenses.list.path],
    queryFn: async () => {
      const res = await fetch(api.expenses.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch expenses");
      return await res.json();
    },
  });
}

export function useCreateExpense() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<InsertExpense, 'userId'>) => {
      const res = await fetch(api.expenses.create.path, {
        method: api.expenses.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create expense");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.expenses.list.path] }),
  });
}

// --- SALES ---
export function useSales() {
  return useQuery<Sale[]>({
    queryKey: [api.sales.list.path],
    queryFn: async () => {
      const res = await fetch(api.sales.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch sales");
      return await res.json();
    },
  });
}

export function useCreateSale() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.sales.create.input>) => {
      const res = await fetch(api.sales.create.path, {
        method: api.sales.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create sale");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.sales.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.products.list.path] }); // update stock
    },
  });
}

// --- WORKERS ---
export function useWorkers() {
  return useQuery<Worker[]>({
    queryKey: [api.workers.list.path],
    queryFn: async () => {
      const res = await fetch(api.workers.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch workers");
      return await res.json();
    },
  });
}

export function useCreateWorker() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<InsertWorker, 'userId'>) => {
      const res = await fetch(api.workers.create.path, {
        method: api.workers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create worker");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.workers.list.path] }),
  });
}

// --- SALARY PAYMENTS ---
export function useSalaryPayments() {
  return useQuery<SalaryPayment[]>({
    queryKey: [api.salaryPayments.list.path],
    queryFn: async () => {
      const res = await fetch(api.salaryPayments.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch salary payments");
      return await res.json();
    },
  });
}

export function useCreateSalaryPayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<InsertSalaryPayment, 'userId'>) => {
      const res = await fetch(api.salaryPayments.create.path, {
        method: api.salaryPayments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create salary payment");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.salaryPayments.list.path] }),
  });
}


  // --- NEW ANALYTICS ---
  export function useForecasting() {
    return useQuery({
      queryKey: [api.analytics.forecasting.path],
      queryFn: async () => {
        const res = await fetch(api.analytics.forecasting.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch forecasting data");
        return await res.json();
      },
    });
  }

  export function useSummary() {
    return useQuery({
      queryKey: [api.analytics.summary.path],
      queryFn: async () => {
        const res = await fetch(api.analytics.summary.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch summary data");
        return await res.json();
      },
    });
  }

  export function useStockRisk() {
    return useQuery({
      queryKey: [api.analytics.stockRisk.path],
      queryFn: async () => {
        const res = await fetch(api.analytics.stockRisk.path, { credentials: "include" });
        if (!res.ok) throw new Error("Failed to fetch stock risk data");
        return await res.json();
      },
    });
  }

  // --- ANALYTICS / CHAT ---
export function useDashboard() {
  return useQuery({
    queryKey: [api.analytics.dashboard.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.dashboard.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard data");
      return await res.json();
    },
  });
}

export function useChat() {
  return useMutation({
    mutationFn: async (query: string) => {
      const res = await fetch(api.analytics.chat.path, {
        method: api.analytics.chat.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Chat request failed");
      const data = await res.json();
      return data.response;
    },
  });
}
