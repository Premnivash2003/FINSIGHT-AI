## Packages
recharts | Dashboard analytics charts and data visualization
date-fns | Human-readable date formatting
lucide-react | Icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}

The backend API uses username/password for authentication, but visually the login form represents the username as the "Email" field for a better SaaS experience.
