# Smart Market Watch - Business Management App

A comprehensive business management application for small businesses, featuring financial tracking, inventory management, sales, expenses, workers, vendors, and AI-powered insights.

## Tech Stack

- **Frontend**: React + Vite + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Session-based with Passport.js
- **AI**: Replit AI Integrations (OpenAI GPT-5.2)
- **Charts**: Recharts
- **Excel**: XLSX for bulk import

## Key Features

### 1. Currency System
- All financial values displayed in Indian Rupees (₹)
- Consistent currency formatting across all pages

### 2. Inventory Management
- Product catalog with categories
- Cost price and selling price tracking
- Current stock levels with reorder alerts
- Low stock indicators
- **CRUD Operations**:
  - ✅ Add new products
  - ✅ Edit product details (name, category, prices, stock, reorder level)
  - ✅ Delete products with confirmation
  - ✅ Bulk import from Excel (.xlsx)
- Real-time stock status indicators

### 3. Sales Tracking
- Sales order management
- Product-wise sales tracking
- Customer information
- Total amount calculations

### 4. Expense Management
- Expense categorization
- Date-wise tracking
- Vendor/supplier linking
- Description and amount tracking

### 5. Vendor Management
- Vendor/supplier directory
- Payment status tracking (Paid/Unpaid)
- Amount to pay tracking
- Contact information (name, email, phone)
- **Actions**:
  - ✅ Add new vendors
  - ✅ Mark payments as paid
  - ✅ Delete vendors with confirmation

### 6. Worker Management
- Employee roster
- Role and salary tracking
- Joining date records
- Monthly salary management
- **Actions**:
  - ✅ Add new workers
  - ✅ Delete/remove workers with confirmation

### 7. AI Advisor (Enhanced)
- Full business context awareness:
  - Revenue data from sales
  - Expense data
  - Inventory levels and product information
  - Worker salary information
  - Vendor payment obligations
- Powered by OpenAI GPT-5.2
- Contextual business recommendations
- Natural language queries about business performance

### 8. Financial Summary Module (NEW)
- **Overview Cards**:
  - Total Revenue
  - Total Expenses
  - Cash Inflow
  - Cash Outflow
  - Net Cashflow
  - Forecast Closing Balance
- **Interactive Charts**:
  - Current vs Forecast comparison
  - Revenue, Expense, Net Cashflow visualization
  - Historical trend analysis

### 9. Predictive Forecasting Module (NEW)
- **AI-Powered Predictions**:
  - Next month revenue forecast
  - Expected expenses
  - Closing balance projection
- **Stock Planning**:
  - Products requiring restocking
  - Quantity recommendations
- **Visual Analytics**:
  - Revenue & Expense forecast charts
  - Stock needed breakdown

### 10. Stock Risk Analysis Module (NEW)
- **Low Stock Detection**:
  - Real-time monitoring of products below reorder level
  - Critical stock alerts
- **Purchase Recommendations**:
  - AI-calculated reorder quantities
  - Automatic recommendations to maintain 2x reorder threshold
- **Risk Dashboard**:
  - Products at risk count
  - Total units needed
  - Overall inventory health indicator
- **Actionable Insights**:
  - AI-powered bulk purchase suggestions
  - Vendor discount optimization tips

## Navigation Structure

Main sidebar navigation includes:
1. Dashboard - Business overview
2. Inventory - Product management
3. Sales - Sales order tracking
4. Expenses - Expense tracking
5. Vendors - Supplier management
6. Workers - Employee management
7. **Summary** - Financial overview with charts
8. **Forecasting** - Predictive analytics
9. **Stock Risk** - Inventory risk monitoring
10. AI Advisor - Business intelligence chat

## Data Synchronization

All modules are interconnected and update in real-time:
- Sales affect inventory stock levels
- Expenses link to vendors
- Worker salaries contribute to expense forecasting
- Inventory levels trigger stock risk alerts
- All data feeds into AI advisor context

## API Endpoints

### Analytics
- `GET /api/analytics/dashboard` - Dashboard metrics
- `GET /api/analytics/forecasting` - Revenue/expense forecasts, stock predictions
- `GET /api/analytics/summary` - Financial summary with charts
- `GET /api/analytics/stock-risk` - Low stock products with recommendations
- `POST /api/chat` - AI advisor queries

### CRUD Operations
- Products: GET, POST, PUT, DELETE `/api/products/:id`
- Sales: GET, POST `/api/sales`
- Expenses: GET, POST `/api/expenses`
- Vendors: GET, POST, PUT, DELETE `/api/vendors/:id`
- Workers: GET, POST, DELETE `/api/workers/:id`

## Database Schema

Using Drizzle ORM with PostgreSQL:
- `users` - Business owner accounts
- `products` - Inventory items
- `sales` - Sales transactions
- `expenses` - Business expenses
- `vendors` - Supplier information
- `workers` - Employee records

## Environment Variables

Required secrets:
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption key
- `AI_INTEGRATIONS_OPENAI_API_KEY` - Auto-configured via Replit AI Integrations
- `AI_INTEGRATIONS_OPENAI_BASE_URL` - Auto-configured via Replit AI Integrations

## Recent Enhancements

### Phase 1: Currency Conversion
- Converted all dollar signs ($) to Indian Rupees (₹)
- Updated all frontend pages and components

### Phase 2: CRUD Functionality
- Added edit/delete buttons to Inventory page
- Added delete buttons to Workers page  
- Added delete buttons to Vendors page
- Modal forms for editing product details
- Confirmation dialogs for deletions
- Real-time cache invalidation

### Phase 3: AI Enhancement
- Integrated Replit AI OpenAI blueprint
- Enhanced AI advisor with full business context
- Implemented GPT-5.2 model for advanced insights
- Context includes revenue, expenses, inventory, workers, vendors

### Phase 4: Analytics Modules
- Created Forecasting page with predictive analytics
- Created Summary page with financial overview and charts
- Created Stock Risk page with low-stock monitoring
- Added navigation links in sidebar
- Implemented responsive chart visualizations

## Development

Run the application:
```bash
npm run dev
```

The application runs on a single port with Vite serving the frontend and Express handling the backend API.

## User Experience Features

- Dark mode support throughout
- Responsive design for mobile/tablet/desktop
- Loading states and error handling
- Toast notifications for user actions
- Hover effects and transitions
- Status badges and color coding
- Search and filter functionality
- Data validation with Zod schemas
