import { z } from 'zod';
import { 
  insertUserSchema, users,
  insertProductSchema, products,
  insertVendorSchema, vendors,
  insertWorkerSchema, workers,
  insertSalaryPaymentSchema, salaryPayments,
  insertSaleSchema, sales,
  insertPurchaseSchema, purchases,
  insertExpenseSchema, expenses
} from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    register: {
      method: 'POST' as const, path: '/api/register' as const,
      input: insertUserSchema,
      responses: { 201: z.custom<typeof users.$inferSelect>(), 400: errorSchemas.validation }
    },
    login: {
      method: 'POST' as const, path: '/api/login' as const,
      input: z.object({ username: z.string(), password: z.string() }),
      responses: { 200: z.custom<typeof users.$inferSelect>(), 401: errorSchemas.unauthorized }
    },
    logout: {
      method: 'POST' as const, path: '/api/logout' as const,
      responses: { 200: z.object({ message: z.string() }) }
    },
    me: {
      method: 'GET' as const, path: '/api/me' as const,
      responses: { 200: z.custom<typeof users.$inferSelect>(), 401: errorSchemas.unauthorized }
    }
  },
  products: {
    list: {
      method: 'GET' as const, path: '/api/products' as const,
      responses: { 200: z.array(z.custom<typeof products.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/products' as const,
      input: insertProductSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof products.$inferSelect>() }
    },
    bulkCreate: {
      method: 'POST' as const, path: '/api/products/bulk' as const,
      input: z.array(insertProductSchema.omit({ userId: true })),
      responses: { 201: z.array(z.custom<typeof products.$inferSelect>()) }
    },
    update: {
      method: 'PUT' as const, path: '/api/products/:id' as const,
      input: insertProductSchema.partial(),
      responses: { 200: z.custom<typeof products.$inferSelect>() }
    },
    delete: {
      method: 'DELETE' as const, path: '/api/products/:id' as const,
      responses: { 204: z.void() }
    }
  },
  vendors: {
    list: {
      method: 'GET' as const, path: '/api/vendors' as const,
      responses: { 200: z.array(z.custom<typeof vendors.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/vendors' as const,
      input: insertVendorSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof vendors.$inferSelect>() }
    },
    update: {
      method: 'PUT' as const, path: '/api/vendors/:id' as const,
      input: insertVendorSchema.partial(),
      responses: { 200: z.custom<typeof vendors.$inferSelect>() }
    },
    delete: {
      method: 'DELETE' as const, path: '/api/vendors/:id' as const,
      responses: { 204: z.void() }
    }
  },
  workers: {
    list: {
      method: 'GET' as const, path: '/api/workers' as const,
      responses: { 200: z.array(z.custom<typeof workers.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/workers' as const,
      input: insertWorkerSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof workers.$inferSelect>() }
    },
    update: {
      method: 'PUT' as const, path: '/api/workers/:id' as const,
      input: insertWorkerSchema.partial(),
      responses: { 200: z.custom<typeof workers.$inferSelect>() }
    }
  },
  salaryPayments: {
    list: {
      method: 'GET' as const, path: '/api/salary-payments' as const,
      responses: { 200: z.array(z.custom<typeof salaryPayments.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/salary-payments' as const,
      input: insertSalaryPaymentSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof salaryPayments.$inferSelect>() }
    },
    update: {
      method: 'PUT' as const, path: '/api/salary-payments/:id' as const,
      input: insertSalaryPaymentSchema.partial(),
      responses: { 200: z.custom<typeof salaryPayments.$inferSelect>() }
    }
  },
  sales: {
    list: {
      method: 'GET' as const, path: '/api/sales' as const,
      responses: { 200: z.array(z.custom<typeof sales.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/sales' as const,
      input: z.object({
        date: z.string(),
        totalAmount: z.number().or(z.string()),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number(),
          unitPrice: z.number().or(z.string())
        }))
      }),
      responses: { 201: z.custom<typeof sales.$inferSelect>() }
    },
    delete: {
      method: 'DELETE' as const, path: '/api/sales/:id' as const,
      responses: { 204: z.void() }
    }
  },
  purchases: {
    list: {
      method: 'GET' as const, path: '/api/purchases' as const,
      responses: { 200: z.array(z.custom<typeof purchases.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/purchases' as const,
      input: insertPurchaseSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof purchases.$inferSelect>() }
    }
  },
  expenses: {
    list: {
      method: 'GET' as const, path: '/api/expenses' as const,
      responses: { 200: z.array(z.custom<typeof expenses.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const, path: '/api/expenses' as const,
      input: insertExpenseSchema.omit({ userId: true }),
      responses: { 201: z.custom<typeof expenses.$inferSelect>() }
    },
    delete: {
      method: 'DELETE' as const, path: '/api/expenses/:id' as const,
      responses: { 204: z.void() }
    }
  },
  analytics: {
    dashboard: {
      method: 'GET' as const, path: '/api/analytics/dashboard' as const,
      responses: { 200: z.any() } 
    },
    forecasting: {
      method: 'GET' as const, path: '/api/analytics/forecasting' as const,
      responses: { 200: z.any() }
    },
    summary: {
      method: 'GET' as const, path: '/api/analytics/summary' as const,
      responses: { 200: z.any() }
    },
    stockRisk: {
      method: 'GET' as const, path: '/api/analytics/stock-risk' as const,
      responses: { 200: z.any() }
    },
    chat: {
      method: 'POST' as const, path: '/api/chat' as const,
      input: z.object({ query: z.string() }),
      responses: { 200: z.object({ response: z.string() }) }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}